		insertId = "000745";
		modifyId = "000746";
		deleteId = "000747";
		queryId = "000748";
		moduleName = "自定义柜员交易权限";
		modulePath = "/cm1/tl/";
		moduleType = "add, edit, query";
		listId = "tlcustomLimList";
		mkArray = ['corp_cd','tl_no'];
		
		insertSuccessMsg = "添加成功";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;