		insertId = "000736";
		modifyId = "000737";
		deleteId = "000738";
		queryId = "000739";
		moduleName = "自定义柜员币种限额参数";
		modulePath = "/cm1/tl/";
		moduleType = "add, query, edit";
		listId = "tlcustomCcyList";
		mkArray = ['ccy', 'tl_no'];
		
		insertSuccessMsg = "添加成功";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;