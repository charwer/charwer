		insertId = "000708";
		modifyId = "000732";
		deleteId = "000733";
		queryId = "000708";
		moduleName = "交易参数信息";
		modulePath = "/cm1/tl/";
		moduleType = "ADD";
		listId = "tlAuthPmList";
		mkArray = ['corp_cd', 'txn_cd', 'seq_no'];
		
		insertSuccessMsg = "添加成功";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;