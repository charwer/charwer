public function RdpPage_dp2207In(trxContext:RdpTrxContextInterface)
{
	super(trxContext);
}


function