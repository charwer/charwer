		function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
	    }
		
		function ffunczikehhaoAfter()            //子客户号域后处理                                              
		{                                                                                              
	    	if( getFieldValue("zikehhao") !=null )  
	       {
		        var indata = new RdpData();
		        indata.put("cu_no",getFieldValue("zikehhao"));                                                                                      
		    	//自定义域后脚本                                                                               	
		    	performTask(ACTION_NONO,"000529",
		    				indata,function(trxContext )
					{
						var outdata  = trxContext.getOutData();
						debug("performPopupTask outdata="+outdata.toString());
						setFieldValue("zikehmin",getDataFieldValue(outdata,"kehuzwmc"));
			    		initPageField(outdata);
						setFieldProtect("zikehmin");
						//focusNowNextField(); 
			    }); 
			}                                                                                      			                                                                                                                                         
		}
		
		function ffunczikehhaoAfter()                                                         
		{                                                                                              
                                                                                   
	    	if( getGridFieldValue("lstrelationsignpart","zikehhao") !=null )  
	       {    
	       
	       		var outData = trxContext.getOutData();
				var indata = new RdpData();
			
				var kehuzhao = getGridFieldValue("lstrelationsignpart","zikehhao");
			
				indata.put("cu_no",getGridFieldValue("lstrelationsignpart","zikehhao"));                                                                                    
		    	//自定义域后脚本                                                                               	
		    	performTask(ACTION_NONO,"000529",
		    				indata,function(trxContext) 
					{
						var outdata = trxContext.getOutData();
						debug("performPopupTask outdata="+outdata.toString());
						
						initPageField(outdata);
						
						setGridFieldValue("lstrelationsignpart","zikehmin",getDataFieldValue(outdata,"kehuzwmc"));

			   		 }); 
				} 
			
//			 this.focusGridNowNextColumn(this.grid.getId());                                                                                      			                                                                                                                                         
		}           
