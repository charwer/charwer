		insertId = "022209";
		modifyId = "000746";
		deleteId = "000747";
		queryId = "022213";
		moduleName = "集团客户资产查询";
		modulePath = "/dp/dept/group/";
		moduleType = "onlyquery";
		listId = "";
		mkArray = ['corp_cd','tl_no'];
		
		insertSuccessMsg = "交易完成";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;
			function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
			setFieldValue("shifoudy","1");
	    }
