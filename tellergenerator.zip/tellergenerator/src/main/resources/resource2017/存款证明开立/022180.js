		insertId = "022180";
		modifyId = "000746";
		deleteId = "000747";
		queryId = "022180";
		moduleName = "存款证明开立";
		modulePath = "/dp/dept/prove/";
		moduleType = "groupsimple";
		listId = "";
		mkArray = ['corp_cd','tl_no'];
		
		insertSuccessMsg = "交易完成";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;
		
		var url022280 = "teller/modules/dp/dept/query/022280dialog.jsp";
		function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
			delListItemByValue("zhmzhlei","");
			delListItemByValue("zhjnzlei","");
	    }
		function ffunczhmzhleiAfter()                                                         
		{                                                                                              
			if( getListFieldValueId("zhmzhlei") == "SDIAN" )
			{
				setFieldProtect("zhzhriqi");
				setFieldValue("zhzhriqi","");
				//add by sudx 20160229南京银行需求增加时点余额类型选项，能选择打印上一日日终余额或是当前余额
				setFieldMustInput("sdyeleix");
			}else if(getListFieldValueId("zhmzhlei") == "SDUAN")
			{
				setFieldInput("zhzhriqi");
				setInputType("zhzhriqi","M");
				//add by sudx 20160229南京银行需求增加时点余额类型选项，能选择打印上一日日终余额或是当前余额
				setFieldProtect("sdyeleix");
				setFieldValue("sdyeleix","");
			}
			//focusNowNextField(); 
		}
		function ffuncfenshuuuAfter()                                                         
		{ 
			// sudx 开立存款证明份数不能为负！！!
			if(!bSpace(getFieldValue("fenshuuu"))){
			        if(str2Int(getFieldValue("fenshuuu"))< 0){
			        	//focusNowNextField("开立存款证明份数不能为负！！!");
				        return;
			        }
		        }  
			var count = getGridTotalLines("listnm01");
			var zongjine = "0";
			for(var i = 0; i < count; i++ )
			{
				var zhmjinee = getGridFieldValueByRowNo("listnm01",i,"zhmjinee"); 
			//	zongjine = zhmjinee + zongjine;
			    zongjine = numAdd(zhmjinee,zongjine);
			}
			setFieldValue("hejijine",zongjine);
			//focusNowNextField(); 
		}
		//凭证序号
		 function ffuncpngzxhaoAfter()                                                         
		{                                                                                              
            //if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域后处理");   
		    //自定义域后处理脚本  
		    //补齐8位长度       
			 setFieldValue("pngzxhao",appendPreZeroByLen(getFieldValue("pngzxhao"),8));
			 //focusNowNextField();
		} 
		//sudx 起始日期不能大于终止日期
	  function ffunczhzhriqiAfter()                                                          
		{                                                                                               
	        if(!bSpace(getSopDate())){
		        if(!bSpace(getFieldValue("zhzhriqi"))){
			        if(str2Int(getSopDate())>str2Int(getFieldValue("zhzhriqi"))){
			        	//focusNowNextField("开立存款证明终止日期不能小于当前交易的系统日期！！!");
				        return;
			        }
		        }	
	        }
	        //focusNowNextField();                                                                                   
		}

	  
		public function ffunczhmjineeAfter()
		{
			
			var count= getGridTotalLines("listnm01");
						
			for(var i = 0; i < count; i++ )
			{	
				
            	 var zmjine = getGridFieldValueByRowNo("listnm01",i,"zhmjinee"); //证明金额
            	 var kyjine = getGridFieldValueByRowNo("listnm01",i,"keyongye"); //可用金额
            	 
			 	if(amountCompare(kyjine,zmjine)<0){
					 // showErrorMessage("证明金额不能大于可用金额！！！", function() : void{}); 		
			   } 
		    }
		  
//		    this.focusGridNowNextColumn(this.grid.getId());  
		}
	  
		public function ffunckehuzhaoAfter()
		{
			//自定义列域后处理
			
			//if( this.trxContext==null )throw new RdpError("交易上下文为空，无法进行域后处理");
				
			var indata = new RdpData();
			
			var kehuzhao = getGridFieldValue("listnm01","kehuzhao");
			
			indata.put("kehuzhao",getGridFieldValue("listnm01","kehuzhao"));
			
			setShowOutGrid(indata,"listnm");//设置判断联动输出页面是否展示的表格如果表格内容只有一行则不显示输出页面
				
   			performTask(ACTION_NOYES_POPUP,"022280",
                        indata,
                        function(trxContext){
                //输出内存空间
                var outData=trxContext.getOutData();

                //根据查询输出结果初始化页面                  		    			
	    		//取得dp2280交易返回列表的当前行的值
	    		var GridSelectedRowLineData = getDataGridSelectedRowLineData(outData,"listnm");		
				//将取得值赋给原查询表格的当前行
				setGridNowLineValue("listnm01",GridSelectedRowLineData);
				
				var gridData1 = getDataFieldValue(outData,"kehuzhao");
	    		setGridFieldValue("listnm01","kehuzhao",gridData1);
	    		
	    		var gridData2 = getDataFieldValue(outData,"pngzzlei");
	    		setGridFieldValue("listnm01","pngzzlei",gridData2);
	    		
	    		var gridData3 = getDataFieldValue(outData,"pngzphao");
	    		setGridFieldValue("listnm01","pngzphao",gridData3);
	    		
	    		var gridData4 = getDataFieldValue(outData,"pngzxhao");
	    		setGridFieldValue("listnm01","pngzxhao",gridData4);
	    		
	    		var gridData5 = getDataFieldValue(outData,"kehuzhmc"); //覆盖列表中客户名称。主卡附卡账户名称不一致
	    		setGridFieldValue("listnm01","zhhuzwmc",gridData5);
	    		
	    		
	    		
	    		
	    		if(getListFieldValueId("pngzzlei") == "GRZKZM" && getListItemIdByValue("E_SUOSHUDX",getDataGridSelectedRowFieldValue(outData, "listnm", "suoshudx"))=="DGCKCP" ){
	    			//throw new RdpError("对公账户无法开立个人存款证明");
	    		}
	    		
	    		if((getListFieldValueId("pngzzlei") == "DGCKZ" || getListFieldValueId("pngzzlei") == "ZXZM" )&& getListItemIdByValue("E_SUOSHUDX",getDataGridSelectedRowFieldValue(outData, "listnm", "suoshudx"))=="DSCKCP"){
	    			//throw new RdpError("个人账户无法开立对公存款证明或者资信证明");
	    		}
	    		
	    		//setGridFieldValue("listnm01","zhmjinee",GridSelectedRowLineData.get("zhhuyuee"));//去查询可用余额。
	    		
	    		var outData1=trxContext.getOutData();
				var indata1 = new RdpData();
			
				var kehuzhao = getGridFieldValue("listnm01","kehuzhao");
				var	zhaoxhao = getGridFieldValue("listnm01","zhhaoxuh");
	    		indata1.put("kehuzhao",kehuzhao);   
				indata1.put("zhhaoxuh",zhaoxhao);  
	    		performTask(ACTION_NONO,"dp2022",indata1,function(trxContext : RdpTrxContextInterface)
				{					
	
						var outdata2 : RdpData = trxContext.getOutData();
						debug("performPopupTask outdata2="+outdata2.toString());
							var syuee = numAdd(getDataFieldValue(outdata2,"konzjine"),getDataFieldValue(outdata2,"donjjine"));
							var skeyon = numSub(getDataFieldValue(outdata2,"zhanghye"),syuee);
						if( getListFieldValueId("zhmzhlei") == "SDIAN" ){
				
						if( getListFieldValueId("sdyeleix") == "SRYE" )
						{
							setGridFieldValue("listnm01","zhmjinee",getDataFieldValue(outdata2,"shrizhye"));//上日余额
							setGridFieldValue("listnm01","keyongye",getDataFieldValue(outdata2,"shrizhye"));//回显账户可用余额
							setGridFieldValue("listnm01","zhanghye",getDataFieldValue(outdata2,"zhanghye"));
							
						}
						else
						{
							setGridFieldValue("listnm01","zhmjinee",skeyon);
							setGridFieldValue("listnm01","keyongye",skeyon);//回显账户可用余额
							setGridFieldValue("listnm01","zhanghye",getDataFieldValue(outdata2,"zhanghye"));
						}	
					}else if(getListFieldValueId("zhmzhlei") == "SDUAN"){
							setGridFieldValue("listnm01","zhmjinee",skeyon);
							setGridFieldValue("listnm01","keyongye",skeyon);//回显账户可用余额
							setGridFieldValue("listnm01","zhanghye",getDataFieldValue(outdata2,"zhanghye"));
					
					}
					else{
						
						setGridFieldValue("listnm01","zhmjinee",skeyon);
						setGridFieldValue("listnm01","keyongye",skeyon);//回显账户可用余额
						setGridFieldValue("listnm01","zhanghye",getDataFieldValue(outdata2,"zhanghye"));
					}
						
				}); 
                //下面处理固定放在所有处理最后，用于光标跳转
                focusGridColumn("listnm01", "zhmjinee");
                }
            ); 
             
		}