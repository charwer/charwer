		insertId = "022182";
		modifyId = "000746";
		deleteId = "000747";
		queryId = "022182";
		moduleName = "存款证明开立";
		modulePath = "/dp/dept/prove/";
		moduleType = "groupsimple";
		listId = "";
		mkArray = ['corp_cd','tl_no'];
		
		insertSuccessMsg = "交易完成";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;
		
		var url022280 = "teller/modules/dp/dept/query/022280dialog.jsp";
		function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
	    }
		//sudx回收存款证明份数不能为负
		function ffuncfenshuuuAfter()
		{
		        if(!bSpace(getFieldValue("fenshuuu"))){
			        if(str2Int(getFieldValue("fenshuuu"))< 0){
			        	//focusNowNextField("回收存款证明份数不能为负！！!");
				        return;
			        }
		        }	
	        //focusNowNextField();   
		} 
		function ffunccunkzmhoAfter()  
		{
		   //if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域后处理");
	       var indata2=new RdpData();
	       		indata2.put("chaxunfs","0");
				indata2.put("cunkzmho",getFieldValue("cunkzmho"));
				performTask(ACTION_NONO,"022184", indata2,function(trxContext){
				//取输出内存
				var outData=trxContext.getOutData();
				var GridSelectedRowLineData2 = getDataGridSelectedRowLineData(outData,"listnm02");
				setFieldValue("fenshuuu",getDataGridSelectedRowFieldValue(outData, "listnm02", "fenshuuu"));
				//focusNowNextField();  
				});
		}
		
		//add by zhangyx 凭证序号补位
		 function ffuncpngzxhaoAfter()                                                         
		{                                                                                              
           //if( this.trxContext==null )throw new RdpError("交易上下文为空，无法进行域后处理");   
		    
		    //自定义域后处理脚本  
		    //补齐8位长度       
			 setGridFieldValue("listnm01","pngzxhao",appendPreZeroByLen(getGridFieldValue("listnm01","pngzxhao"),8));
          
			 //focusNowNextField();
              
		}                                                                                      
		
		function ffuncXXXXAfter()
		{
			//自定义列域后处理
			//this.focusGridNowNextColumn(this.grid.getId());
		}		
package com.rdp.busi.trx.tdp2182In
{
	public class RdpPage_dp2182In extends RdpProjectPageScriptAbstract
	{
		function RdpPage_dp2182In(trxContext)
		{
			//super(trxContext);
		}
		function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
	    }
		function pageSubmit():Boolean
		{
			if( !//super.pageSubmit() )return false;
			//自定义提交脚本
			return true;
		}
		function pagePrintInit():Boolean
		{
			if( !//super.pagePrintInit() )return false;
			//自定义打印初始化脚本
			return true;
		}
		function pageAfterCall():Boolean
		{
			this.trxContext.setSubmitContinue(true);
			//自定义通讯后处理脚本
			if( !//super.pageAfterCall() ) return false;
			return true;
		}
		function ffuncXXXXXPre()                                                           
		{                                                                                                                                                                                     
			//if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域前处理");   
			//自定义域前处理脚本                                                                                                                                                            
		}        
		function ffuncXXXXXAfter()                                                         
		{                                                                                              
	    	//if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域后处理");   
	    	//自定义域后脚本                                                                       
			//focusNowNextField();                                                                                                                                          
		}  
		//sudx回收存款证明份数不能为负
		function ffuncfenshuuuAfter()
		{
		        if(!bSpace(getFieldValue("fenshuuu"))){
			        if(str2Int(getFieldValue("fenshuuu"))< 0){
			        	//focusNowNextField("回收存款证明份数不能为负！！!");
				        return;
			        }
		        }	
	        //focusNowNextField();   
		} 
		function ffunccunkzmhoAfter()  
		{
		   //if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域后处理");
	       var indata2=new RdpData();
	       		indata2.put("chaxunfs","0");
				indata2.put("cunkzmho",getFieldValue("cunkzmho"));
				performTask(ACTION_NONO,"dp2184", indata2,function(trxContext){
				//取输出内存
				var outData=trxContext.getOutData();
				var GridSelectedRowLineData2 = getDataGridSelectedRowLineData(outData,"listnm02");
				setFieldValue("fenshuuu",getDataGridSelectedRowFieldValue(outData, "listnm02", "fenshuuu"));
				//focusNowNextField();  
				});
		}                                                                                         
	}
}
