		insertId = "022209";
		modifyId = "000746";
		deleteId = "000747";
		queryId = "022209";
		moduleName = "全集团关系查询";
		modulePath = "/dp/dept/group/";
		moduleType = "onlyquery";
		listId = "";
		mkArray = ['corp_cd','tl_no'];
		
		insertSuccessMsg = "交易完成";
		modifySuccessMsg = "修改成功";
		suffix = ".jsp";
		addUrl =  modulePath + insertId + suffix;
		editUrl = modulePath + modifyId + suffix;
		
		var url022280 = "teller/modules/dp/dept/query/022280dialog.jsp";
			function pageInit()
		{
			//super.pageInit();
			//自定义初始化脚本
	    }
		
		//子列表页的
		 function gridDoubleClick()
		{
			//表格行双击事件处理
			//super.gridDoubleClick();
			
			showGridNowDetail("lstqjtgx");
			//自定义处理过程
		}
		
		
	//	function ffuncQUERYBUTTONAfter()                                                         
	//	{                                                                                              
	//    	//if( this.trxContext==null )//focusNowNextField("交易上下文为空，无法进行域后处理");   
	//        if( !bSubmitCheck() )return;                                                                                                                                                                 
            //联动 查询处理开始
   //         var inData = getContainerAllFieldData("para_condition");
	//		performTask(ACTION_NONO,"dp2209",
   //                     inData,
    //                    function(trxContext){
                //输出内存空间
    //            var outData=trxContext.getOutData();
	//			initPageField(outData);
                //下面处理固定放在所有处理最后，用于光标跳转
     //           //focusNowNextField(); 
     //           });
     //      }	                                                                                                        
