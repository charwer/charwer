package org.charwer.zx.tg.analyse;

import java.io.IOException;
import java.util.List;
import org.charwer.zx.tg.ModuleConfig;
import org.jsoup.nodes.Document;

public interface Analyser {

	void setConfig(ModuleConfig config);
	
	String analyse() throws IOException;

	List<String> cutTheJspHead() throws IOException;

	List<String> saveTheJspHead(List<String> strList);

	Document doJspCommonBefore(List<String> strList);

	String getButtonPanelElement(String fileName) throws IOException;

	String doJspCommonAfter(Document doc, List<String> jspHeadList);

	//restore the camel form name
	String killJsoupBug(String result);

	String getPageId();
}