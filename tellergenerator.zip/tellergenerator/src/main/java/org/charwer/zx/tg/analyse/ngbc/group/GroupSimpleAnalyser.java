package org.charwer.zx.tg.analyse.ngbc.group;

import javax.script.ScriptEngine;

import org.charwer.zx.tg.analyse.AbstractAnalyser;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class GroupSimpleAnalyser extends AbstractAnalyser {

	@Override
	protected void customAnalyse(Document doc) {
		//删除返回报文所在layout
		doc.getElementById("outSys").parent().parent().remove();
		
		super.onEnter(doc);
	}

	@Override
	public String getPageId() {
		return config.getQueryId();
	}

	@Override
	protected String getButtonPageName() {
		return "buttonGroupSimple";
	}

	@Override
	protected String getLabel() {
		return config.getModuleName();
	}
	
	@Override
	public void doScript(Element script){
		script.attr("type", "text/javascript");
		script.attr("src", "../../js/dp.js");
		script.attr("module", config.getQueryId());
	}
}
