package org.charwer.zx.tg;

import static org.charwer.zx.tg.ModuleConfig.generateBasePath;
import static org.charwer.zx.tg.ModuleConfig.resourceBasePath;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.script.ScriptException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.NameFileFilter;
import org.apache.commons.io.filefilter.NotFileFilter;
import org.charwer.zx.tg.analyse.Analyser;
import org.charwer.zx.tg.generate.DefaultGenerator;
import org.charwer.zx.tg.generate.Generator;
import org.charwer.zx.tg.type.AnalyserType;

public class GenerateRunner {

	public static void main(String[] args) throws IOException, NoSuchMethodException, ScriptException {
		Properties props = initGlobal();
		resourceBasePath = props.getProperty("resourceBasePath");
		generateBasePath = props.getProperty("generateBasePath");
		generate();
	}
	
	private static Properties initGlobal() throws FileNotFoundException, IOException{
		Properties props = new Properties();
		props.load(new FileReader(GenerateRunner.class.getResource("/").getPath() + File.separator + "config.properties"));
		return props;
	}
	
	public static void generate() throws NoSuchMethodException, ScriptException, IOException{
		File[] dirs = filterModulesDirs();
		for(File file:dirs){
			//isSkip
			
			File fileIO = new File(file, "skip.io");
			if(fileIO.exists()){
				String skip = FileUtils.readFileToString(fileIO);
				if("skip".equalsIgnoreCase(skip)){
					System.out.println(file.getName() + "was skipped");
					continue;
				}
			}
			
			Generator generator = init(file);
			generator.generate();
		}
	}
	
	private static File[] filterModulesDirs(){
		FilenameFilter finalFilter = FileFilterUtils.and(new NotFileFilter(new NameFileFilter("button")), DirectoryFileFilter.INSTANCE);
		File[] dirs = new File(resourceBasePath).listFiles(finalFilter);
		return dirs;
	}
	
	private static Generator init(File file) throws NoSuchMethodException, ScriptException, IOException{
		ModuleConfig moduleConfig = new ModuleConfig();
		moduleConfig.setResourceModulePath(resourceBasePath + file.getName() + File.separator);
		ModuleConfigPicker.doConfig(moduleConfig);
		
		Generator generator = new DefaultGenerator();
		moduleConfig.setGenerateModulePath(generateBasePath + moduleConfig.getModulePath());
		generator.setModuleConfig(moduleConfig);
		
		List<Analyser> listAnalyser = new ArrayList<Analyser>();
		String[] types = moduleConfig.getModuleType().toUpperCase().split(",");
		for(String type: types){
			listAnalyser.add(AnalyserType.valueOf(type.trim()).getAnalyser());
		}
		
		generator.setAnalyserList(listAnalyser);
		return generator;
	}
	
}
