package org.charwer.zx.tg;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

public class RegularTest {

	public static void main(String[] args) throws IOException {
		
		String path = "E:\\workshop-core-1.0\\project_workspace\\tellergenerator\\src\\main\\resources\\";
    	File asFile = FileUtils.iterateFiles(new File(path), new String[]{"as"}, false).next();
    	String asString = ModuleConfigPicker.readAsFile(asFile);
    	
    	String regEx = "import [A-Za-z1-9\\.\\*]+;";
    	Pattern pattern = Pattern.compile(regEx);
    	Matcher matcher = pattern.matcher(asString);
    	String s = matcher.replaceAll("");
    	StringBuilder sb = new StringBuilder();
    	String thisLine = "";
    	BufferedReader sr = new BufferedReader(new StringReader(s));
    	try {
			while((thisLine = sr.readLine()) != null){
				if(thisLine.matches("[\\s]*")) continue;
				sb.append(thisLine);
				sb.append("\r\n");
			}
		} catch (IOException e) {
			// ch Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
//	    System.out.println(sb.toString());
    	String ex = "function RdpPage_\\w*\\(trxContext\\)\\s*\\{(.|\\s)*\\}(?=(?:\\s*function))";
    	Pattern p = Pattern.compile(ex);
    	
//		String path2 = "E:\\workshop-core-1.0\\project_workspace\\tellergenerator\\src\\main\\resources\\";
//		File file = new File(path2, "temp2.js");
//		String str;
//			str = FileUtils.readFileToString(file);
//    	Matcher m = p.matcher(str);
    	
    	//这块代码给线程干死了,400行的as文件
			Matcher m = p.matcher(sb.toString());
			String s2 = m.replaceAll("fuck!");
			System.out.println(s2);
	}

}
