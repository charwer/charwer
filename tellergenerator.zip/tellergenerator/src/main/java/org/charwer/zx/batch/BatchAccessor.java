package org.charwer.zx.batch;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;

public class BatchAccessor {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		
		String content = FileUtils.readFileToString(new File(BatchAccessor.class.getResource("/batch/content.json").getFile()), "UTF-8");
//		
//		CloseableHttpClient httpclient = HttpClients.createDefault();
//		HttpPost httpPost = new HttpPost("http://localhost:8080/scheduler$schedulerService$fireJob.do?_t=1481510763526");
//		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
//		nvps.add(new BasicNameValuePair("content", content));
//		httpPost.setEntity(new UrlEncodedFormEntity(nvps));
//		CloseableHttpResponse response2 = httpclient.execute(httpPost);
//
//		try {
//		    System.out.println(response2.getStatusLine());
//		    HttpEntity entity2 = response2.getEntity();
//		    // do something useful with the response body
//		    // and ensure it is fully consumed
//		    EntityUtils.consume(entity2);
//		} finally {
//		    response2.close();
//		}
		
		String sync = "{\"_resourceId\":\"0\",\"_description\":\"任务配置\",\"_requestType\":\"iframe\"}";
		
		Request.Post("http://localhost:8080/scheduler$schedulerService$syncEvent.do?_t=1481680599800")
		.bodyForm(Form.form().add("content",  sync).build())
		.execute().returnContent();
		
		Request.Post("http://localhost:8080/scheduler$schedulerService$fireJob.do?_t=1481510763526")
	    .bodyForm(Form.form().add("content",  content).build())
	    .execute().returnContent();
	}
	

}
