package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;


public class SimpleAnalyser extends AbstractAnalyser {

	@Override
	protected void customAnalyse(Document doc) {
		//删除返回报文所在layout
		doc.getElementById("outSys").parent().parent().remove();
	}

	@Override
	public String getPageId() {
		return config.getQueryId();
	}

	@Override
	protected String getButtonPageName() {
		return "buttonSimple";
	}

	@Override
	protected String getLabel() {
		return "";
	}
}
