package org.charwer.zx.tg.generate;

import static org.charwer.zx.tg.ModuleConfig.ENCODE;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.SystemUtils;
import org.charwer.zx.tg.ModuleConfig;
import org.charwer.zx.tg.analyse.Analyser;


public abstract class AbstractGenerator implements Generator {

	protected ModuleConfig moduleConfig;
	
	public ModuleConfig getModuleConfig() {
		return moduleConfig;
	}
	
	protected List<Analyser> anylserList;
	
	@Override
	public void setModuleConfig(ModuleConfig moduleConfig) {
		this.moduleConfig = moduleConfig;
	}
	
	@Override
	public void setAnalyserList(List<Analyser> analyserList){
		this.anylserList = analyserList;
	}

	public  void jsGenerate() throws IOException{
		File jsFile = moduleConfig.getJsFile();
		File newJsDir = new File(moduleConfig.getGenerateModulePath() + "js");
		FileUtils.copyFileToDirectory(jsFile,  newJsDir);
		
		StringBuffer sb = new StringBuffer();
		sb.append(SystemUtils.LINE_SEPARATOR);
		sb.append("postListsIdStr='" + moduleConfig.getPostListsIdStr() + "';");
		
		FileUtils.write(new File(newJsDir, jsFile.getName()), sb.toString(), ENCODE, true);
	}
	
	public abstract void customGenerate() throws IOException;
	
	@Override
	public void generate() throws IOException{
		customGenerate();
		jsGenerate();
	}
	
	@Override
	public void generatePage(Analyser analyser) throws IOException{
		FileUtils.write(new File(moduleConfig.getGenerateModulePath() + analyser.getPageId() + moduleConfig.getSuffix()), analyser.analyse(), ENCODE);
	}
}
