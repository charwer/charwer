package org.charwer.zx.tg;

import static org.charwer.zx.tg.ModuleConfig.ADD_URL;
import static org.charwer.zx.tg.ModuleConfig.DELETE_ID;
import static org.charwer.zx.tg.ModuleConfig.EDIT_URL;
import static org.charwer.zx.tg.ModuleConfig.ENCODE;
import static org.charwer.zx.tg.ModuleConfig.INSERT_ID;
import static org.charwer.zx.tg.ModuleConfig.INSERT_SUCCESS_MSG;
import static org.charwer.zx.tg.ModuleConfig.LIST_ID;
import static org.charwer.zx.tg.ModuleConfig.MK_ARRAY;
import static org.charwer.zx.tg.ModuleConfig.MODIFY_ID;
import static org.charwer.zx.tg.ModuleConfig.MODIFY_SUCCESS_MSG;
import static org.charwer.zx.tg.ModuleConfig.MODULE_NAME;
import static org.charwer.zx.tg.ModuleConfig.MODULE_PATH;
import static org.charwer.zx.tg.ModuleConfig.MODULE_TYPE;
import static org.charwer.zx.tg.ModuleConfig.QUERY_ID;
import static org.charwer.zx.tg.ModuleConfig.SUFFIX;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class ModuleConfigPicker {

	static Logger logger=Logger.getLogger(ModuleConfigPicker.class.getName());
			
	
	public static String readAsFile(File file) {
		try {
			StringBuilder sb = new StringBuilder();
			String encoding = "UTF-8";
//			File file = new File(filePath);
			String regEx = "a|f"; // 表示a或f
			Pattern p = null;
			Matcher m = null;
			boolean result = false;
			boolean outFlg = true;
			String enumKey = "";
			String tableId = "";
			HashMap<String,String> resultMap = null;
			// 获取jsp中空间对应的tableid
			
			if (file.isFile() && file.exists()) { // 判断文件是否存在
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);// 考虑到编码格式
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				while ((lineTxt = bufferedReader.readLine()) != null) {
					outFlg = true;

					// 不需要显示的内容
					if (lineTxt.indexOf("package com") > 0 || lineTxt.indexOf("import com") > 0 
							|| lineTxt.indexOf("super.pageInit()") > 0
							|| lineTxt.indexOf("focusNowNextField") > 0
							|| lineTxt.indexOf("throw new RdpError") > 0
							) {
						outFlg = false;
					}

					// 需要替换的内容
					lineTxt = lineTxt.replaceAll("override ", "");
//					lineTxt = lineTxt.replaceAll("function(trxContext ", "{},function(trxContext");
					lineTxt = lineTxt.replaceAll("public function", "function");
					lineTxt = lineTxt.replaceAll(":void", "");
					lineTxt = lineTxt.replaceAll(":String", "");
					lineTxt = lineTxt.replaceAll(":RdpData", "");
					lineTxt = lineTxt.replaceAll(": RdpData", "");
					lineTxt = lineTxt.replaceAll(":RdpTrxContextInterface", "");
					lineTxt = lineTxt.replaceAll(": RdpTrxContextInterface", "");
					lineTxt = lineTxt.replaceAll(" : RdpTrxContextInterface", "");
					lineTxt = lineTxt.replaceAll(" : void", "");
					lineTxt = lineTxt.replaceAll(": void", "");
					lineTxt = lineTxt.replaceAll(":void", "");
					lineTxt = lineTxt.replaceAll(":Number", "");
					lineTxt = lineTxt.replaceAll(": Number", "");
					lineTxt = lineTxt.replaceAll(":RdpCollection", "");
					lineTxt = lineTxt.replaceAll(": RdpCollection", "");
					lineTxt = lineTxt.replaceAll(": String", "");
					lineTxt = lineTxt.replaceAll(":String", "");
					lineTxt = lineTxt.replaceAll("\"E_", "\"L_");

					// getFieldValue, setFieldValue,setFieldInput判断控件id是否存在



//						System.out.println(lineTxt);
					sb.append(lineTxt);
					sb.append("\n");
				}
				read.close();
				return sb.toString();
			} else {
				System.out.println("[异常]-找不到指定的文件");
			}
		} catch (Exception e) {
			System.out.println("[异常]-读取文件内容出错");
			e.printStackTrace();
		}
		return "";
		

	}
	
    public static void doConfig(ModuleConfig moduleConfig) throws ScriptException, NoSuchMethodException, IOException{ 
    	//init javascript engine
    	ScriptEngineManager manager = new ScriptEngineManager();  
    	ScriptEngine engine = manager.getEngineByName("JavaScript");  
    	//read js file
    	File jsFile = FileUtils.iterateFiles(new File(moduleConfig.getResourceModulePath()), new String[]{"js"}, false).next();
    	
    	System.out.println(jsFile.getParentFile().getName() + ":");
    	//fufa dealing .as
    	File asFile = FileUtils.iterateFiles(new File(moduleConfig.getResourceModulePath()), new String[]{"as"}, false).next();
    	String StringTempJsFilePath = "E:\\workshop-core-1.0\\project_workspace\\tellergenerator\\src\\main\\resources\\temp.js";
    	File tempJsFile = new File(StringTempJsFilePath);
    	String asString = readAsFile(asFile);
    	
    	
    	//regular one more dealing
       	String regEx = "import [A-Za-z1-9\\.\\*]+;";
    	Pattern pattern = Pattern.compile(regEx);
    	Matcher matcher = pattern.matcher(asString);
    	String s = matcher.replaceAll("");
    	
    	s= s.replaceAll("super", "//super")
    	.replaceAll("focusNowNextField", "//focusNowNextField")
    	.replaceAll("throw new RdpError", "//focusNowNextField")
    	.replaceAll("if\\( this\\.trxContext==null", "//if\\( this\\.trxContext==null");
    	
    	StringBuilder sb = new StringBuilder();
    	String thisLine = "";
    	BufferedReader sr = new BufferedReader(new StringReader(s));
    	try {
			while((thisLine = sr.readLine()) != null){
				if(thisLine.matches("[\\s]*")) continue;
				sb.append(thisLine);
				sb.append("\r\n");
			}
		} catch (IOException e) {
			// ch Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	FileUtils.writeStringToFile(tempJsFile , sb.toString());
    	File flagFile = null;
    	String flagString = null;
    	boolean flag = false;
    	flagFile  = FileUtils.iterateFiles(new File(moduleConfig.getResourceModulePath()), new String[]{"txt"}, false).next();
    	try {
			while(true){
				Thread.sleep(10000);
				flagString = FileUtils.readFileToString(flagFile);
				flag = Boolean.parseBoolean(flagString);
				if(flag){
					break;
				}
			}
			
		} catch (InterruptedException e) {
			// ch Auto-generated catch block
			e.printStackTrace();
		}
    	
    	//append to js file
    	FileUtils.writeStringToFile(jsFile, FileUtils.readFileToString(tempJsFile, "UTF-8"), true);
    	
    	String script = FileUtils.readFileToString(jsFile, ENCODE);
    	//load the js file with engine
//        engine.eval(new FileReader(jsFile));
        engine.eval(script);
        //read and save config
        moduleConfig.setInsertId(engine.get(INSERT_ID).toString());
        moduleConfig.setModifyId(engine.get(MODIFY_ID).toString());
        moduleConfig.setDeleteId(engine.get(DELETE_ID).toString());
        moduleConfig.setQueryId(engine.get(QUERY_ID).toString());
        moduleConfig.setModuleName(engine.get(MODULE_NAME).toString());
        moduleConfig.setModulePath(engine.get(MODULE_PATH).toString());
        moduleConfig.setModuleType(engine.get(MODULE_TYPE).toString());
        moduleConfig.setListId(engine.get(LIST_ID).toString());
        moduleConfig.setMkArray(engine.get(MK_ARRAY).toString());
        moduleConfig.setInsertSuccessMsg(engine.get(INSERT_SUCCESS_MSG).toString());
        moduleConfig.setModifySuccessMsg(engine.get(MODIFY_SUCCESS_MSG).toString());
        moduleConfig.setSuffix(engine.get(SUFFIX).toString());
        moduleConfig.setAddUrl(engine.get(ADD_URL).toString());
        moduleConfig.setEditUrl(engine.get(EDIT_URL).toString());
        moduleConfig.setJsFile(jsFile);
        
        moduleConfig.setEngine(engine);
    } 
    
	//just for test
    public static void greet() throws ScriptException, NoSuchMethodException{
    	ScriptEngineManager manager = new ScriptEngineManager();  
        ScriptEngine engine = manager.getEngineByName("JavaScript");
//      engine.eval("println('hello,java7!')");  
//      engine.eval("println(2 + 3)");  
        String func = "function add(a, b){c = a + b; return c;}";
        engine.eval(func);
        Invocable jsInvoke = (Invocable)engine;
        Object result = jsInvoke.invokeFunction("add", new Object[]{3, 4});
        System.out.println(result);
    }

}
