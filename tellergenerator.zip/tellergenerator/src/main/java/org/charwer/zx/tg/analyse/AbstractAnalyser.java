package org.charwer.zx.tg.analyse;

import static org.charwer.zx.tg.ModuleConfig.ENCODE;
import static org.charwer.zx.tg.ModuleConfig.resourceBasePath;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.script.ScriptEngine;

import org.apache.commons.collections.ListUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.charwer.zx.tg.ModuleConfig;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public abstract class AbstractAnalyser implements Analyser {

	protected ModuleConfig config;
	
	@Override
	public void setConfig(ModuleConfig config) {
		this.config = config;
	}
	
	@Override
	public String analyse() throws IOException{
		//读取查询页面文件,并处理掉jsp头
		List<String> strList = cutTheJspHead();
		List<String> jspHeadList = saveTheJspHead(strList);

		//jsp common deal before
		Document doc = doJspCommonBefore(strList);
		
		Element select = doc.getElementsByTag("t:titlepanel").first();
		select.attr("label", getLabel());
		select.getElementById("input").attr("title", "");
		
		//关键按键处理
		Element buttonPanel = doc.getElementsByTag("t:buttonpanel").first();
		Element buttonLayout = buttonPanel.parent();
		buttonLayout.append(getButtonPanelElement(getButtonPageName()));
		buttonPanel.remove();
		
		//返回报文处理
		customAnalyse(doc);
		
		//列表ids提取
		config.setPostListsIdStr(extractListsId(select));
		
		//jsp common deal after
		String result = doJspCommonAfter(doc, jspHeadList);
		return killJsoupBug(result);
	}
	
	protected String extractListsId(Element titlePanel){
		Set<String> idSet = new HashSet<String>();
		Elements elementsByTag = titlePanel.getElementsByTag("t:table");
		Elements elementsByTag2 = titlePanel.getElementsByTag("t:grid");
		List<Element> lists = ListUtils.union(elementsByTag, elementsByTag2);
		for(Element e:lists){
			idSet.add(e.id());
		}
		return StringUtils.join(idSet.toArray(new String[idSet.size()]), ",");
	}
	
	@Override
	public List<String> cutTheJspHead() throws IOException{
		//处理jsp头
		String jspPath = config.getResourceModulePath() + getPageId() + config.getSuffix();
		List<String> strList = FileUtils.readLines(new File(jspPath), ENCODE);
		return strList;
	}
	
	@Override
	public List<String> saveTheJspHead(List<String> strList){
		List<String> jspHeadList = new ArrayList<String>();
		for(int i = 0; i < 3; i++){
			jspHeadList.add(strList.remove(0));
		}
		return jspHeadList;
	}
	
	@Override
	public Document doJspCommonBefore(List<String> strList){
		//生成Jsoup DOM
		String html = StringUtils.join(strList, "");
//		System.out.println(html);
		Document doc = Jsoup.parse(html);
		//删除原来的js脚本
		doc.getElementsByTag("script").remove();
		Element script = doc.head().appendElement("script");
		//引入通用js
		doScript(script);
		//找到历史输入layout
		Element historyLayout = doc.getElementById("fileTable").parent().parent();
		//删除历史结点
		historyLayout.remove();
		//删除授权流水号等
		doc.select("#inSys").remove();
		return doc;
	}
	
	public void doScript(Element script){
		script.attr("type", "text/javascript");
		script.attr("src", "../js/cm1.js");
		script.attr("module", config.getQueryId());
	}
	
	protected void onEnter(Document doc){
		//为有事件的元素加上onenter事件
		Element select = doc.getElementsByTag("t:titlepanel").first();
		
		Elements elements = select.getElementsByTag("t:text");
		ScriptEngine engine = config.getEngine();
		for(Element e:elements){
			String id = e.id();
			String funcName = "ffunc" + id + "After";
			if(null != engine.get(funcName)){
				e.attr("onenter", funcName + "()");
			}
			
			if(e.attr("label").contains("日期")){
				e.attr("mask", "date");
			}
		}
	}
	
	@Override
	public String getButtonPanelElement(String fileName) throws IOException{
		String buttonFilePath = resourceBasePath + "button" + File.separator + fileName + config.getSuffix();
		return FileUtils.readFileToString(FileUtils.getFile(buttonFilePath), ENCODE);
	}
	
	@Override
	public String doJspCommonAfter(Document doc, List<String> jspHeadList){
		//加入jsp头
		List<String> docList = Arrays.asList(StringUtils.split(doc.html(), System.getProperty("line.separator")));
		@SuppressWarnings("unchecked")
		List<String> unionList = ListUtils.union(jspHeadList, docList);
		//生成最终的查询页代码
		return StringUtils.join(unionList, System.getProperty("line.separator"));
	}
	
	@Override
	public String killJsoupBug(String result){
		result = result.replaceAll("enumtype", "enumType").replaceAll("buttontype", "buttonType").replaceAll("maxheight", "maxHeight")
		.replaceAll("readonly", "readOnly");
		return result;
	}
	
	protected abstract void customAnalyse(Document doc);
	
	@Override
	public abstract String getPageId();
	
	protected abstract String getButtonPageName();
	
	protected abstract String getLabel();

}
