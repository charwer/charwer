package org.charwer.zx.tg.generate;

import java.io.IOException;
import org.charwer.zx.tg.analyse.Analyser;


public class DefaultGenerator extends AbstractGenerator {

	@Override
	public void customGenerate() throws IOException {
		for(Analyser a:this.anylserList){
			a.setConfig(moduleConfig);
			a.analyse();
			generatePage(a);
		}
	}
	
}
