package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;
import static org.charwer.zx.tg.ModuleConfig.*;

public class AddAnalyser extends AbstractAnalyser {

	@Override
	public String getPageId() {
		return config.getInsertId();
	}

	@Override
	protected String getButtonPageName() {
		return "buttonAdd";
	}

	@Override
	protected String getLabel() {
		return "新增";
	}

	@Override
	protected void customAnalyse(Document doc) {
		//删除返回报文所在layout
		doc.getElementById("outSys").parent().parent().remove();
	}

}
