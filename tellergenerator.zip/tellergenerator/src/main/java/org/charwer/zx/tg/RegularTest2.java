package org.charwer.zx.tg;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

public class RegularTest2 {

	public static void main(String[] args) throws IOException  {
		String path = "E:\\workshop-core-1.0\\project_workspace\\tellergenerator\\src\\main\\resources\\";
		File file = new File(path, "temp2.js");
		String str = FileUtils.readFileToString(file);
		String ex = "public function RdpPage_\\w*\\(trxContext:RdpTrxContextInterface\\)\\s*\\{(.|\\s)*\\}(?=(?:\\s*function))";
//		Matcher matcher = Pattern.compile(ex).matcher("function RdpPage_dp2207In(trxContext)"
		Matcher matcher = Pattern.compile(ex).matcher(str);
		System.out.println(matcher.replaceAll("fuck!"));
	}

}
