package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class OnlyQueryAnalyser extends QueryAnalyser {
	
	@Override
	protected void customAnalyse(Document doc) {
		Element outSysElement = doc.getElementById("outSys");
		outSysElement.nextElementSibling().remove();
		outSysElement.parent().attr("label", "查询结果");
		outSysElement.remove();	
		
		super.onEnter(doc);
	}
	
	@Override
	protected String getButtonPageName() {
		return "buttonOnlyQuery";
	}
	
	@Override
	protected String getLabel() {
		return config.getModuleName();
	}
	
	@Override
	public void doScript(Element script){
		script.attr("type", "text/javascript");
		script.attr("src", "../../js/dp.js");
		script.attr("module", config.getQueryId());
	}
}
