package org.charwer.zx.tg.type;

import org.charwer.zx.tg.analyse.AddAnalyser;
import org.charwer.zx.tg.analyse.Analyser;
import org.charwer.zx.tg.analyse.EditAnalyser;
import org.charwer.zx.tg.analyse.OnlyQueryAnalyser;
import org.charwer.zx.tg.analyse.QueryAnalyser;
import org.charwer.zx.tg.analyse.ngbc.group.GroupSimpleAnalyser;

public enum AnalyserType {
	ADD(new AddAnalyser()), QUERY(new QueryAnalyser()),ONLYQUERY(new OnlyQueryAnalyser()),
	EDIT(new EditAnalyser()), GROUPSIMPLE(new GroupSimpleAnalyser());
	
	private Analyser analyser;
	
	AnalyserType(Analyser analyser){
		this.analyser = analyser;
	}
	
	public Analyser getAnalyser(){
		return analyser;
	}
	
}
