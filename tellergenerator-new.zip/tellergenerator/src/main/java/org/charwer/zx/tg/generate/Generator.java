package org.charwer.zx.tg.generate;

import java.io.IOException;
import java.util.List;
import org.charwer.zx.tg.ModuleConfig;
import org.charwer.zx.tg.analyse.Analyser;

public interface Generator {
	void setAnalyserList(List<Analyser> analyser);
	void setModuleConfig(ModuleConfig config);
	void generate() throws IOException;
	void generatePage(Analyser analyser) throws IOException;
}
