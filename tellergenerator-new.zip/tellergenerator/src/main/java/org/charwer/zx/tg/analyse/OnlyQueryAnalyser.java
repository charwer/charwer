package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class OnlyQueryAnalyser extends QueryAnalyser {
	
	@Override
	protected void customAnalyse(Document doc) {
		Element outSysElement = doc.getElementById("outSys");
		outSysElement.nextElementSibling().remove();
		outSysElement.parent().attr("label", "查询结果");
		outSysElement.remove();		
	}
}
