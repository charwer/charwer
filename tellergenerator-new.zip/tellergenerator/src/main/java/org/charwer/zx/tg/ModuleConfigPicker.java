package org.charwer.zx.tg;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import static org.charwer.zx.tg.ModuleConfig.*;

public class ModuleConfigPicker {

	static Logger logger=Logger.getLogger(ModuleConfigPicker.class.getName());
			
    public static void doConfig(ModuleConfig moduleConfig) throws ScriptException, NoSuchMethodException, IOException{ 
    	//init javascript engine
    	ScriptEngineManager manager = new ScriptEngineManager();  
    	ScriptEngine engine = manager.getEngineByName("JavaScript");  
    	//read js file
    	File jsFile = FileUtils.iterateFiles(new File(moduleConfig.getResourceModulePath()), new String[]{"js"}, false).next();
    	String script = FileUtils.readFileToString(jsFile, ENCODE);
    	//load the js file with engine
//        engine.eval(new FileReader(jsFile));
        engine.eval(script);
        //read and save config
        moduleConfig.setInsertId(engine.get(INSERT_ID).toString());
        moduleConfig.setModifyId(engine.get(MODIFY_ID).toString());
        moduleConfig.setDeleteId(engine.get(DELETE_ID).toString());
        moduleConfig.setQueryId(engine.get(QUERY_ID).toString());
        moduleConfig.setModuleName(engine.get(MODULE_NAME).toString());
        moduleConfig.setModulePath(engine.get(MODULE_PATH).toString());
        moduleConfig.setModuleType(engine.get(MODULE_TYPE).toString());
        moduleConfig.setListId(engine.get(LIST_ID).toString());
        moduleConfig.setMkArray(engine.get(MK_ARRAY).toString());
        moduleConfig.setInsertSuccessMsg(engine.get(INSERT_SUCCESS_MSG).toString());
        moduleConfig.setModifySuccessMsg(engine.get(MODIFY_SUCCESS_MSG).toString());
        moduleConfig.setSuffix(engine.get(SUFFIX).toString());
        moduleConfig.setAddUrl(engine.get(ADD_URL).toString());
        moduleConfig.setEditUrl(engine.get(EDIT_URL).toString());
        moduleConfig.setJsFile(jsFile);
    } 
    
	//just for test
    public static void greet() throws ScriptException, NoSuchMethodException{
    	ScriptEngineManager manager = new ScriptEngineManager();  
        ScriptEngine engine = manager.getEngineByName("JavaScript");
//      engine.eval("println('hello,java7!')");  
//      engine.eval("println(2 + 3)");  
        String func = "function add(a, b){c = a + b; return c;}";
        engine.eval(func);
        Invocable jsInvoke = (Invocable)engine;
        Object result = jsInvoke.invokeFunction("add", new Object[]{3, 4});
        System.out.println(result);
    }

}
