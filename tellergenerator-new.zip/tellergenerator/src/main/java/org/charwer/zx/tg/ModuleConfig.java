package org.charwer.zx.tg;

import java.io.File;
import org.apache.commons.io.FilenameUtils;

public class ModuleConfig {
	
	private String insertId;
	private String modifyId;
	private String deleteId;
	private String queryId;
	private String moduleName;
	private String modulePath;
	private String moduleType;
	private String listId;
	private String mkArray;
	private String insertSuccessMsg;
	private String modifySuccessMsg;
	private String suffix;
	private String addUrl;
	private String editUrl;
	private String postListsIdStr;
	
	public String getPostListsIdStr() {
		return postListsIdStr;
	}
	
	public void setPostListsIdStr(String postListsIdStr) {
		this.postListsIdStr = postListsIdStr;
	}

	public String getInsertId() {
		return insertId;
	}
	
	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}
	
	public String getModifyId() {
		return modifyId;
	}
	
	public void setModifyId(String modifyId) {
		this.modifyId = modifyId;
	}
	
	public String getDeleteId() {
		return deleteId;
	}
	
	public void setDeleteId(String deleteId) {
		this.deleteId = deleteId;
	}
	
	public String getQueryId() {
		return queryId;
	}
	
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}
	
	public String getModuleName() {
		return moduleName;
	}
	
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModulePath() {
		return modulePath;
	}
	
	public void setModulePath(String modulePath) {
		this.modulePath = modulePath;
	}
	
	public String getModuleType() {
		return moduleType;
	}
	
	public void setModuleType(String moduleType) {
		this.moduleType = moduleType;
	}
	
	public String getListId() {
		return listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}
	
	public String getMkArray() {
		return mkArray;
	}
	
	public void setMkArray(String mkArray) {
		this.mkArray = mkArray;
	}
	
	public String getInsertSuccessMsg() {
		return insertSuccessMsg;
	}
	
	public void setInsertSuccessMsg(String insertSuccessMsg) {
		this.insertSuccessMsg = insertSuccessMsg;
	}
	
	public String getModifySuccessMsg() {
		return modifySuccessMsg;
	}
	
	public void setModifySuccessMsg(String modifySuccessMsg) {
		this.modifySuccessMsg = modifySuccessMsg;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	
	public String getAddUrl() {
		return addUrl;
	}
	
	public void setAddUrl(String addUrl) {
		this.addUrl = addUrl;
	}
	
	public String getEditUrl() {
		return editUrl;
	}
	
	public void setEditUrl(String editUrl) {
		this.editUrl = editUrl;
	}
	
	private File jsFile;
	
	public File getJsFile() {
		return jsFile;
	}
	
	public void setJsFile(File jsFile) {
		this.jsFile = jsFile;
	}

	public static final String INSERT_ID = "insertId";
	public static final String MODIFY_ID = "modifyId";
	public static final String DELETE_ID = "deleteId";
	public static final String QUERY_ID = "queryId";
	public static final String MODULE_NAME = "moduleName";
	public static final String MODULE_PATH = "modulePath";
	public static final String MODULE_TYPE = "moduleType";
	public static final String LIST_ID = "listId";
	public static final String MK_ARRAY = "mkArray";
	public static final String INSERT_SUCCESS_MSG = "insertSuccessMsg";
	public static final String MODIFY_SUCCESS_MSG = "modifySuccessMsg";
	public static final String SUFFIX = "suffix";
	public static final String ADD_URL = "addUrl";
	public static final String EDIT_URL = "editUrl";
	
	public static final String ENCODE = "UTF-8";
	
//	public static String basePath = FilenameUtils.getFullPath("E:\\workshop-core-1.0\\project_workspace\\ngbc\\teller\\src\\main\\webapp\\teller\\modules\\");
	
	public static String resourceBasePath;
	public static String generateBasePath;
	
	public String resourceModulePath;
	
	public String getResourceModulePath() {
		return resourceModulePath;
	}
	
	public void setResourceModulePath(String resourceModulePath) {
		this.resourceModulePath = resourceModulePath;
	}
	
	public String generateModulePath;

	
	public String getGenerateModulePath() {
		return generateModulePath;
	}
	
	public void setGenerateModulePath(String generateModulePath) {
		this.generateModulePath = generateModulePath;
	}
	
}
