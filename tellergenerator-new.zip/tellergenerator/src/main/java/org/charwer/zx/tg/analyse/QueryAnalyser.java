package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class QueryAnalyser extends AbstractAnalyser {
	
	@Override
	public String getPageId() {
		return config.getQueryId();
	}

	@Override
	protected String getButtonPageName() {
		return "buttonQuery";
	}

	@Override
	protected String getLabel() {
		return "查询";
	}

	@Override
	protected void customAnalyse(Document doc) {
		Element outSysElement = doc.getElementById("outSys");
		outSysElement.nextElementSibling().remove();
		outSysElement.parent().attr("label", "查询结果");
		outSysElement.remove();		
		
		doc.getElementById(config.getListId()).attr("mode", "radio");
	}

}
