package org.charwer.zx.tg.analyse;

import org.jsoup.nodes.Document;
import static org.charwer.zx.tg.ModuleConfig.*;

public class EditAnalyser extends AbstractAnalyser {

	@Override
	public String getPageId() {
		return config.getModifyId();
	}

	@Override
	protected String getButtonPageName() {
		return "buttonEdit";
	}

	@Override
	protected String getLabel() {
		return "修改";
	}

	@Override
	protected void customAnalyse(Document doc) {
		//删除返回报文所在layout
		doc.getElementById("outSys").parent().parent().remove();
		doc.getElementsByTag("t:body").get(0).attr("onload", "init();loadData()");
	}

}
