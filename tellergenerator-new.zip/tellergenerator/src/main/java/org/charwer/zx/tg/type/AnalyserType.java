package org.charwer.zx.tg.type;

import org.charwer.zx.tg.analyse.AddAnalyser;
import org.charwer.zx.tg.analyse.Analyser;
import org.charwer.zx.tg.analyse.EditAnalyser;
import org.charwer.zx.tg.analyse.QueryAnalyser;

public enum AnalyserType {
	ADD(new AddAnalyser()), QUERY(new QueryAnalyser()), EDIT(new EditAnalyser());
	
	private Analyser analyser;
	
	AnalyserType(Analyser analyser){
		this.analyser = analyser;
	}
	
	public Analyser getAnalyser(){
		return analyser;
	}
	
}
