package yangyong;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class ParseXML {
	
	public static void main(String[] args) throws Exception {
		parseXML();
	}

	private static void parseXML() throws Exception {
		SAXReader reader = new SAXReader();
		try {
			Document newDoc = DocumentHelper.createDocument();
			Element serviceMapping = newDoc.addElement("serviceMapping");
			Element inMappings = serviceMapping.addElement("inMappings");
			Element outMappings = serviceMapping.addElement("outMappings");
			
			// 读取XML文件
			Document doc = reader.read("c:\\NewFile.xml");
			Element root = doc.getRootElement();
			Element in_mapping = root.element("in_mappings");
			Element out_mapping = root.element("out_mappings");
			List<Element> in_mappingList = in_mapping.elements();
			List<Element> out_mappingList = out_mapping.elements();
			
			serviceMapping.addAttribute("id", root.attributeValue("serviceName"));
			serviceMapping.addAttribute("desc", root.attributeValue("longname"));
			serviceMapping.addAttribute("mappingToProperty", root.attributeValue("mappingToProperty"));
			for(Element mapping : in_mappingList){
				Element inMapping = inMappings.addElement("mapping");
				inMapping.addAttribute("src", mapping.attributeValue("src"));
				inMapping.addAttribute("dest", mapping.attributeValue("dest"));
			}
			
			for(Element mapping : out_mappingList){
				Element outMapping = outMappings.addElement("mapping");
				outMapping.addAttribute("src", mapping.attributeValue("src"));
				outMapping.addAttribute("dest", mapping.attributeValue("dest"));
			}
			
			//实例化输出格式对象
			  OutputFormat format = OutputFormat.createPrettyPrint();
			  //设置输出编码
			  format.setEncoding("UTF-8");
			  //创建需要写入的File对象
			  File file = new File("C:" + File.separator + "result.xml");
			  //生成XMLWriter对象，构造函数中的参数为需要输出的文件流和格式
			  XMLWriter writer = new XMLWriter(new FileOutputStream(file), format);
			  //开始写入，write方法中包含上面创建的Document对象
			  writer.write(newDoc);
			
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}
	
}
